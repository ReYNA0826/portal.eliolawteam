export interface Paralegal {
  id: number;
  name: string;
  email: string;
  status: 'available' | 'busy';
  nextAppointments: string[];
}

export interface User extends Paralegal {
  // Can extend if we have specific user properties later
}

export type ViewMode = 'welcome' | 'login' | 'dashboard' | 'client';

export interface ClientFormData {
  clientType: 'new' | 'regular';
  language: 'es' | 'en';
  isPhoneAppointment: boolean;
  fullName: string;
  phone: string;
  email: string;
  caseType: string;
  // Regular specific
  assignedParalegalId?: number;
  questions?: string;
  // New specific
  referralSource?: string;
}
