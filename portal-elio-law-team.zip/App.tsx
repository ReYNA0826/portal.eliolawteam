import React, { useState } from 'react';
import LoginParalegal from './components/LoginParalegal';
import Dashboard from './components/Dashboard';
import WelcomeScreen from './components/WelcomeScreen';
import ClientPortal from './components/ClientPortal';
import { Paralegal, ViewMode } from './types';

function App() {
  const [currentView, setCurrentView] = useState<ViewMode>('welcome');
  const [user, setUser] = useState<Paralegal | null>(null);

  const handleRoleSelection = (role: 'client' | 'staff') => {
    if (role === 'client') {
      setCurrentView('client');
    } else {
      setCurrentView('login');
    }
  };

  const handleLogin = (loggedInUser: Paralegal) => {
    setUser(loggedInUser);
    setCurrentView('dashboard');
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentView('welcome'); // Or 'login' depending on preference
  };

  const handleBackToWelcome = () => {
    setCurrentView('welcome');
  };

  switch (currentView) {
    case 'client':
      return <ClientPortal onBack={handleBackToWelcome} />;
    case 'login':
      return <LoginParalegal onLogin={handleLogin} />; // Ideally add a 'back' button in login too, but prompt didn't specify.
    case 'dashboard':
      if (!user) return <LoginParalegal onLogin={handleLogin} />;
      return <Dashboard currentUser={user} onLogout={handleLogout} />;
    case 'welcome':
    default:
      return <WelcomeScreen onSelectRole={handleRoleSelection} />;
  }
}

export default App;
