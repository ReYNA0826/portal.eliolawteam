import React, { useEffect, useRef, useState, memo } from "react";
import { GoogleGenAI, LiveServerMessage, Modality, Blob } from "@google/genai";
import { Mic, MicOff, X, Activity } from "lucide-react";

interface VoiceAssistantProps {
  isOpen: boolean;
  onClose: () => void;
  userName: string;
}

const VoiceAssistant: React.FC<VoiceAssistantProps> = ({ isOpen, onClose, userName }) => {
  const [isConnected, setIsConnected] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Audio Context Refs
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const sessionRef = useRef<any>(null);

  // Clean up function
  const cleanup = () => {
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    if (inputAudioContextRef.current) {
      inputAudioContextRef.current.close();
      inputAudioContextRef.current = null;
    }
    if (outputAudioContextRef.current) {
      outputAudioContextRef.current.close();
      outputAudioContextRef.current = null;
    }
    sourcesRef.current.forEach(source => source.stop());
    sourcesRef.current.clear();
    setIsConnected(false);
    setIsSpeaking(false);
  };

  useEffect(() => {
    if (!isOpen) {
      cleanup();
      return;
    }

    const startSession = async () => {
      try {
        setError(null);
        
        // Initialize Audio Contexts
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        inputAudioContextRef.current = new AudioContextClass({ sampleRate: 16000 });
        outputAudioContextRef.current = new AudioContextClass({ sampleRate: 24000 });
        
        const outputNode = outputAudioContextRef.current!.createGain();
        outputNode.connect(outputAudioContextRef.current!.destination);

        // Get API Key - Support both Node (AI Studio) and Vite (SiteGround) environments
        const apiKey = process.env.API_KEY || (import.meta as any).env?.VITE_API_KEY;
        
        if (!apiKey) throw new Error("API Key missing");

        const ai = new GoogleGenAI({ apiKey });

        // Connect to Gemini Live
        const sessionPromise = ai.live.connect({
          model: 'gemini-2.5-flash-native-audio-preview-09-2025',
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
              voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
            },
            systemInstruction: `You are a helpful legal assistant for a paralegal named ${userName}. You are concise, professional, and helpful.`,
          },
          callbacks: {
            onopen: async () => {
              setIsConnected(true);
              
              // Setup Input Stream
              try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                const source = inputAudioContextRef.current!.createMediaStreamSource(stream);
                const scriptProcessor = inputAudioContextRef.current!.createScriptProcessor(4096, 1, 1);
                
                scriptProcessor.onaudioprocess = (e) => {
                  const inputData = e.inputBuffer.getChannelData(0);
                  const pcmBlob = createBlob(inputData);
                  
                  sessionPromise.then(session => {
                    session.sendRealtimeInput({ media: pcmBlob });
                  });
                };
                
                source.connect(scriptProcessor);
                scriptProcessor.connect(inputAudioContextRef.current!.destination);
              } catch (err) {
                console.error("Microphone access error:", err);
                setError("Microphone access denied.");
              }
            },
            onmessage: async (message: LiveServerMessage) => {
              const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
              
              if (base64Audio && outputAudioContextRef.current) {
                 setIsSpeaking(true);
                 const ctx = outputAudioContextRef.current;
                 
                 // Decode
                 const audioBuffer = await decodeAudioData(
                   decode(base64Audio),
                   ctx,
                   24000,
                   1
                 );

                 // Schedule Playback
                 nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
                 
                 const source = ctx.createBufferSource();
                 source.buffer = audioBuffer;
                 source.connect(outputNode);
                 
                 source.addEventListener('ended', () => {
                   sourcesRef.current.delete(source);
                   if (sourcesRef.current.size === 0) setIsSpeaking(false);
                 });
                 
                 source.start(nextStartTimeRef.current);
                 nextStartTimeRef.current += audioBuffer.duration;
                 sourcesRef.current.add(source);
              }

              if (message.serverContent?.interrupted) {
                sourcesRef.current.forEach(s => s.stop());
                sourcesRef.current.clear();
                nextStartTimeRef.current = 0;
                setIsSpeaking(false);
              }
            },
            onclose: () => {
              setIsConnected(false);
            },
            onerror: (e) => {
              console.error("Session error:", e);
              setError("Connection error occurred.");
            }
          }
        });
        
        sessionRef.current = await sessionPromise;

      } catch (err) {
        console.error(err);
        setError("Failed to initialize voice session.");
        setIsConnected(false);
      }
    };

    startSession();

    return cleanup;
  }, [isOpen, userName]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="bg-brand-darker border border-brand-gold rounded-2xl w-full max-w-md p-6 relative shadow-2xl overflow-hidden">
        {/* Abstract background blobs */}
        <div className="absolute top-[-50%] left-[-50%] w-[200%] h-[200%] bg-[radial-gradient(circle,rgba(207,174,112,0.1)_0%,rgba(0,0,0,0)_60%)] pointer-events-none"></div>

        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-white/50 hover:text-white transition-colors"
        >
          <X size={24} />
        </button>

        <div className="flex flex-col items-center justify-center space-y-8 py-8 relative z-10">
          <div className="text-center space-y-2">
            <h3 className="text-2xl font-bold font-sans text-white">Asistente de Voz AI</h3>
            <p className="text-brand-gold text-sm font-serif">Conectado con Gemini Live</p>
          </div>

          <div className="relative">
             {/* Pulse Effect */}
            <div className={`absolute inset-0 rounded-full bg-brand-gold blur-xl transition-all duration-300 ${isSpeaking ? 'opacity-40 scale-150 animate-pulse' : 'opacity-10 scale-100'}`}></div>
            
            <div className={`w-24 h-24 rounded-full flex items-center justify-center transition-all duration-500 border-2 ${isConnected ? 'bg-brand-gold border-brand-gold text-brand-dark' : 'bg-gray-800 border-gray-600 text-gray-400'}`}>
              {isConnected ? <Activity size={40} className={isSpeaking ? "animate-bounce" : ""} /> : <MicOff size={40} />}
            </div>
          </div>

          <div className="text-center min-h-[24px]">
             {error ? (
               <span className="text-red-400 text-sm font-medium bg-red-900/20 px-3 py-1 rounded-full">{error}</span>
             ) : (
                <span className="text-white/70 text-sm font-medium animate-pulse">
                  {isConnected ? (isSpeaking ? "Hablando..." : "Escuchando...") : "Conectando..."}
                </span>
             )}
          </div>
        </div>
      </div>
    </div>
  );
};

// Utils for Audio
function createBlob(data: Float32Array): Blob {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: 'audio/pcm;rate=16000',
  };
}

function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export default memo(VoiceAssistant);