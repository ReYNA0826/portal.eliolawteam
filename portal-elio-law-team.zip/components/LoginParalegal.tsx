import React, { useState } from "react";
import { PARALEGALS } from "../constants";
import { Paralegal } from "../types";
import { Scale } from "lucide-react";

interface LoginProps {
  onLogin: (user: Paralegal) => void;
}

const LoginParalegal: React.FC<LoginProps> = ({ onLogin }) => {
  const [email, setEmail] = useState("");
  const [error, setError] = useState<string | null>(null);

  const handleLogin = () => {
    const normalized = email.trim().toLowerCase();
    
    // In a real app, strict checking. Here we allow name matching for demo purposes
    // if the email doesn't exactly match the mock data
    const user = PARALEGALS.find(
      (p) => p.email.toLowerCase() === normalized || p.name.toLowerCase().includes(normalized)
    );

    if (!user) {
      setError("Email no encontrado en el sistema.");
      return;
    }

    onLogin(user);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-brand-dark to-brand-darker flex items-center justify-center p-4 font-sans text-white">
      <div className="bg-black/35 backdrop-blur-md rounded-2xl p-10 w-full max-w-md border border-brand-gold/40 shadow-2xl">
        <div className="text-center mb-8">
          {/* Logo Container */}
          <div className="w-24 h-24 rounded-2xl mx-auto mb-6 bg-black flex flex-col items-center justify-center shadow-2xl border border-brand-gold/30 relative overflow-hidden group">
            <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_0%,rgba(207,174,112,0.2),transparent)]"></div>
            <Scale size={42} className="text-brand-gold mb-1 group-hover:scale-110 transition-transform duration-500" strokeWidth={1.5} />
            <div className="text-[10px] text-brand-gold font-serif tracking-widest opacity-80 mt-1">JUSTICE</div>
          </div>
          
          <h2 className="m-0 text-2xl font-bold font-sans">Login Paralegal</h2>
          <p className="mt-2 text-sm text-white/70">
            Ingresa con tu email registrado en el sistema interno.
          </p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-medium mb-1.5 text-white/90 uppercase tracking-wide">
              Email
            </label>
            <input
              type="email"
              placeholder="ejemplo@correo.com"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                setError(null);
              }}
              onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
              className="w-full px-4 py-3 rounded-lg border border-white/20 bg-black/30 text-white placeholder-white/30 focus:outline-none focus:border-brand-gold transition-colors"
            />
          </div>

          {error && (
            <div className="text-brand-danger text-xs text-center bg-brand-danger/10 py-2 rounded">
              {error}
            </div>
          )}

          <button
            onClick={handleLogin}
            className="w-full py-3 rounded-lg border-none bg-gradient-to-br from-brand-gold to-brand-goldLight text-brand-dark font-bold text-sm uppercase tracking-wider hover:brightness-110 active:scale-[0.98] transition-all cursor-pointer shadow-lg"
          >
            Entrar
          </button>
        </div>

        <p className="mt-6 text-xs text-white/60 text-center">
          Si tu email no está registrado, contacta a administración.
        </p>
      </div>
    </div>
  );
};

export default LoginParalegal;