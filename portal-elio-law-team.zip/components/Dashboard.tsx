import React, { useState } from "react";
import {
  CheckCircle,
  XCircle,
  Users,
  Clock,
  Calendar,
  User,
  Shield,
  ChevronRight,
  Activity,
  LogOut,
  Mic,
  Scale
} from "lucide-react";
import { Paralegal } from "../types";
import { PARALEGALS } from "../constants";
import VoiceAssistant from "./VoiceAssistant";

interface DashboardProps {
  currentUser: Paralegal;
  onLogout: () => void;
}

type DashboardViewMode = 'paralegal' | 'admin';

const Dashboard: React.FC<DashboardProps> = ({ currentUser, onLogout }) => {
  const [viewMode, setViewMode] = useState<DashboardViewMode>("paralegal");
  const [paralegals, setParalegals] = useState<Paralegal[]>(PARALEGALS);
  const [isVoiceOpen, setIsVoiceOpen] = useState(false);

  // Derived state for the current user's current status in the full list
  const myStatus = paralegals.find(p => p.id === currentUser.id)?.status || 'available';

  const toggleMyStatus = () => {
    setParalegals(prev => prev.map(p => 
      p.id === currentUser.id 
        ? { ...p, status: p.status === 'available' ? 'busy' : 'available' }
        : p
    ));
  };

  const toggleParalegalStatus = (id: number) => {
    setParalegals(prev => prev.map(p => 
      p.id === id 
        ? { ...p, status: p.status === 'available' ? 'busy' : 'available' }
        : p
    ));
  };

  // Stats
  const availableCount = paralegals.filter(p => p.status === 'available').length;
  const busyCount = paralegals.filter(p => p.status === 'busy').length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-brand-dark to-[#003d7a] font-serif text-white selection:bg-brand-gold selection:text-brand-dark">
      <VoiceAssistant 
        isOpen={isVoiceOpen} 
        onClose={() => setIsVoiceOpen(false)} 
        userName={currentUser.name} 
      />

      {/* HEADER */}
      <header className="bg-black/20 backdrop-blur-md border-b border-brand-gold/30 sticky top-0 z-50 px-6 py-4">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-black border border-brand-gold/30 flex items-center justify-center shadow-lg shadow-brand-gold/10 relative overflow-hidden group shrink-0">
               <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_0%,rgba(207,174,112,0.2),transparent)]"></div>
              <Scale size={24} className="text-brand-gold relative z-10 group-hover:scale-110 transition-transform duration-500" strokeWidth={1.5} />
            </div>
            <div>
              <h1 className="m-0 text-lg sm:text-xl font-sans font-bold tracking-tight">Panel de Paralegales</h1>
              <p className="m-0 text-xs sm:text-sm text-brand-gold font-light">EV Immigration Law Team</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
             {/* View Selector */}
            <div className="bg-white/10 rounded-xl p-1 flex gap-1 border border-brand-gold/30">
              <button
                onClick={() => setViewMode("paralegal")}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs sm:text-sm font-sans font-semibold transition-all ${
                  viewMode === "paralegal" 
                    ? "bg-brand-gold text-brand-dark shadow-sm" 
                    : "text-white hover:bg-white/5"
                }`}
              >
                <User size={16} />
                <span className="hidden sm:inline">Paralegal</span>
              </button>
              <button
                onClick={() => setViewMode("admin")}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs sm:text-sm font-sans font-semibold transition-all ${
                  viewMode === "admin" 
                    ? "bg-brand-gold text-brand-dark shadow-sm" 
                    : "text-white hover:bg-white/5"
                }`}
              >
                <Shield size={16} />
                <span className="hidden sm:inline">Admin</span>
              </button>
            </div>
            
            <button 
                onClick={onLogout}
                className="p-3 rounded-lg bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-colors border border-transparent hover:border-white/20"
                title="Cerrar Sesión"
            >
                <LogOut size={18} />
            </button>
          </div>
        </div>
      </header>

      {/* MAIN CONTENT */}
      <main className="max-w-7xl mx-auto p-4 sm:p-8">
        {viewMode === "paralegal" ? (
          <div className="space-y-8 animate-fade-in">
            {/* Top Row: Profile + AI Action */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Profile Card */}
                <div className="md:col-span-2 bg-white/5 rounded-2xl p-6 border border-brand-gold/30 flex items-center gap-5">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-brand-gold to-brand-goldLight flex items-center justify-center text-2xl font-bold text-brand-dark shadow-md shrink-0">
                        {currentUser.name.split(" ").map((n) => n[0]).join("")}
                    </div>
                    <div>
                        <h2 className="text-2xl font-sans font-bold m-0">{currentUser.name}</h2>
                        <p className="text-brand-gold mt-1">Paralegal Legal</p>
                    </div>
                </div>

                {/* AI Assistant Button */}
                <button 
                    onClick={() => setIsVoiceOpen(true)}
                    className="group relative overflow-hidden bg-gradient-to-r from-purple-900/60 to-blue-900/60 hover:from-purple-800/60 hover:to-blue-800/60 border border-indigo-400/30 rounded-2xl p-6 flex flex-col justify-center items-center transition-all duration-300 hover:shadow-[0_0_20px_rgba(100,100,255,0.3)] cursor-pointer"
                >
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.1),transparent)] opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                    <div className="bg-indigo-500 rounded-full p-3 mb-2 shadow-lg group-hover:scale-110 transition-transform">
                        <Mic size={24} className="text-white" />
                    </div>
                    <span className="font-sans font-bold text-lg text-white">Asistente AI</span>
                    <span className="text-xs text-indigo-200 mt-1">Hablar con Gemini Live</span>
                </button>
            </div>

            {/* STATUS TOGGLE BLOCK */}
            <div className={`relative rounded-[20px] p-8 sm:p-12 text-center border-2 transition-all duration-500 shadow-2xl ${
                myStatus === 'available' 
                    ? 'bg-brand-success/10 border-brand-success shadow-brand-success/10' 
                    : 'bg-brand-danger/10 border-brand-danger shadow-brand-danger/10'
            }`}>
              <div className="mb-8">
                <Activity size={48} className={`mx-auto mb-4 ${myStatus === 'available' ? 'text-brand-success' : 'text-brand-danger'}`} />
                <h3 className="text-2xl font-sans font-bold mb-2">Estado de Disponibilidad</h3>
                <p className="text-white/70">Controla cuando puedes recibir nuevas citas.</p>
              </div>

              <button
                onClick={toggleMyStatus}
                className={`w-full max-w-sm mx-auto p-6 rounded-2xl border-none font-sans font-bold text-xl sm:text-2xl flex items-center justify-center gap-4 cursor-pointer transition-transform hover:scale-[1.02] active:scale-[0.98] shadow-xl text-white ${
                    myStatus === 'available'
                        ? 'bg-gradient-to-br from-brand-success to-green-600'
                        : 'bg-gradient-to-br from-brand-danger to-red-700'
                }`}
              >
                {myStatus === 'available' ? (
                  <>
                    <CheckCircle size={32} />
                    <span>DISPONIBLE</span>
                  </>
                ) : (
                  <>
                    <XCircle size={32} />
                    <span>NO DISPONIBLE</span>
                  </>
                )}
              </button>
            </div>

            {/* APPOINTMENTS */}
            <div className="bg-white/5 rounded-2xl p-6 sm:p-8 border border-brand-gold/30">
              <div className="flex items-center gap-3 mb-6 pb-4 border-b border-brand-gold/30">
                <Calendar size={24} className="text-brand-gold" />
                <h3 className="text-xl font-sans font-bold m-0">Próximas Citas</h3>
              </div>

              {currentUser.nextAppointments.length > 0 ? (
                <div className="flex flex-col gap-4">
                  {currentUser.nextAppointments.map((apt, idx) => (
                    <div key={idx} className="bg-brand-gold/10 border border-brand-gold/30 border-l-4 border-l-brand-gold rounded-xl p-5 flex items-center gap-4 hover:bg-brand-gold/15 transition-colors cursor-default">
                      <Clock size={20} className="text-brand-gold shrink-0" />
                      <span className="flex-1 text-base">{apt}</span>
                      <ChevronRight size={20} className="text-white/50" />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 text-white/50">
                  <Calendar size={48} className="mx-auto mb-4 opacity-30" />
                  <p>No tienes citas programadas</p>
                </div>
              )}
            </div>
          </div>
        ) : (
          /* ADMIN VIEW */
          <div className="animate-fade-in">
            <div className="flex items-center gap-3 mb-8">
              <Users size={32} className="text-brand-gold" />
              <h2 className="text-2xl sm:text-3xl font-sans font-bold m-0">Panel de Administración</h2>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
              <div className="bg-brand-success/15 rounded-2xl p-6 border border-brand-success/30">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm text-white/70 m-0">Disponibles</p>
                    <p className="text-4xl font-sans font-bold text-brand-success mt-2 m-0">{availableCount}</p>
                  </div>
                  <CheckCircle size={40} className="text-brand-success opacity-50" />
                </div>
              </div>

              <div className="bg-brand-danger/15 rounded-2xl p-6 border border-brand-danger/30">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm text-white/70 m-0">Ocupados</p>
                    <p className="text-4xl font-sans font-bold text-brand-danger mt-2 m-0">{busyCount}</p>
                  </div>
                  <XCircle size={40} className="text-brand-danger opacity-50" />
                </div>
              </div>

              <div className="bg-brand-gold/15 rounded-2xl p-6 border border-brand-gold/30">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm text-white/70 m-0">Total Equipo</p>
                    <p className="text-4xl font-sans font-bold text-brand-gold mt-2 m-0">{paralegals.length}</p>
                  </div>
                  <Users size={40} className="text-brand-gold opacity-50" />
                </div>
              </div>
            </div>

            {/* Paralegal Table */}
            <div className="bg-white/5 rounded-2xl border border-brand-gold/30 overflow-hidden">
              <div className="bg-brand-gold/20 p-5 grid grid-cols-[2fr_1fr_3fr_120px] gap-4 font-sans font-bold text-xs sm:text-sm uppercase text-brand-gold tracking-wider hidden md:grid">
                <div>Paralegal</div>
                <div>Estado</div>
                <div>Próximas Citas</div>
                <div>Acción</div>
              </div>

              <div className="divide-y divide-brand-gold/20">
                {paralegals.map((paralegal) => (
                  <div key={paralegal.id} className="p-6 grid grid-cols-1 md:grid-cols-[2fr_1fr_3fr_120px] gap-4 items-center">
                    {/* Name */}
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-gradient-to-br from-brand-gold to-brand-goldLight flex items-center justify-center text-sm sm:text-base font-bold text-brand-dark shrink-0">
                        {paralegal.name.split(" ").map((n) => n[0]).join("")}
                      </div>
                      <span className="font-medium text-base sm:text-lg">{paralegal.name}</span>
                    </div>

                    {/* Status Badge */}
                    <div className="flex">
                      <span className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-sans font-bold border ${
                        paralegal.status === 'available' 
                            ? 'bg-brand-success/20 text-brand-success border-brand-success' 
                            : 'bg-brand-danger/20 text-brand-danger border-brand-danger'
                      }`}>
                        {paralegal.status === 'available' ? <CheckCircle size={14} /> : <XCircle size={14} />}
                        {paralegal.status === 'available' ? 'ON' : 'OFF'}
                      </span>
                    </div>

                    {/* Appts */}
                    <div className="text-sm text-white/80">
                      {paralegal.nextAppointments.length > 0 ? (
                        <div className="flex flex-col gap-1">
                          {paralegal.nextAppointments.slice(0, 2).map((apt, i) => (
                            <div key={i} className="flex items-center gap-2 truncate">
                              <div className="w-1.5 h-1.5 rounded-full bg-brand-gold shrink-0" />
                              <span className="truncate">{apt}</span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <span className="text-white/40 italic">Sin citas</span>
                      )}
                    </div>

                    {/* Action */}
                    <div>
                      <button
                        onClick={() => toggleParalegalStatus(paralegal.id)}
                        className="w-full sm:w-auto px-4 py-2 rounded-lg border border-brand-gold bg-brand-gold/10 text-brand-gold font-sans font-semibold text-xs hover:bg-brand-gold hover:text-brand-dark transition-all"
                      >
                        Cambiar
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>

      <footer className="border-t border-brand-gold/30 p-8 text-center bg-black/20 mt-16">
        <p className="m-0 text-sm text-white/60">Elio Vázquez Immigration Law Team</p>
        <p className="mt-2 text-xs text-brand-gold">Desde 1987 • Servicio a la comunidad inmigrante</p>
      </footer>
    </div>
  );
};

export default Dashboard;