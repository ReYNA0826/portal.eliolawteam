import React, { useState } from "react";
import { 
  ArrowLeft, 
  CheckCircle, 
  Globe, 
  Phone, 
  Mail, 
  User, 
  FileText, 
  Calendar,
  Info,
  Scale
} from "lucide-react";
import { PARALEGALS } from "../constants";
import { ClientFormData } from "../types";

interface ClientPortalProps {
  onBack: () => void;
}

const translations = {
  es: {
    back: "Volver",
    title: "Portal de Clientes",
    subtitle: "Agenda tu cita y gestiona tu caso",
    availabilityTitle: "Paralegales Disponibles Ahora",
    noAvailability: "No hay paralegales disponibles en este momento.",
    formTitle: "Agendar Cita",
    clientTypeNew: "Nueva Cita",
    clientTypeRegular: "Cliente Regular",
    phoneAppt: "Prefiero Cita Telefónica",
    fullName: "Nombre Completo",
    phone: "Teléfono",
    email: "Correo Electrónico",
    caseType: "Tipo de Trámite",
    selectParalegal: "Paralegal que prepara sus documentos",
    questions: "Preguntas / Instrucciones para el Paralegal",
    howDidYouHear: "¿Cómo supo de nosotros?",
    sourceInstagram: "Instagram",
    sourceGoogle: "Google",
    sourceYouTube: "YouTube",
    sourceReferral: "Recomendación de otro cliente",
    sourceOther: "Otro",
    submit: "Solicitar Cita",
    successTitle: "¡Solicitud Enviada!",
    successMessage: "Hemos recibido tu información. Nos pondremos en contacto contigo pronto para confirmar la cita.",
    close: "Cerrar",
    selectOption: "Seleccione una opción..."
  },
  en: {
    back: "Back",
    title: "Client Portal",
    subtitle: "Schedule your appointment and manage your case",
    availabilityTitle: "Paralegals Available Now",
    noAvailability: "No paralegals available at the moment.",
    formTitle: "Schedule Appointment",
    clientTypeNew: "New Appointment",
    clientTypeRegular: "Regular Client",
    phoneAppt: "I prefer Phone Appointment",
    fullName: "Full Name",
    phone: "Phone Number",
    email: "Email Address",
    caseType: "Case Type",
    selectParalegal: "Paralegal preparing your documents",
    questions: "Questions / Instructions for Paralegal",
    howDidYouHear: "How did you hear about us?",
    sourceInstagram: "Instagram",
    sourceGoogle: "Google",
    sourceYouTube: "YouTube",
    sourceReferral: "Referral from another client",
    sourceOther: "Other",
    submit: "Request Appointment",
    successTitle: "Request Sent!",
    successMessage: "We have received your information. We will contact you shortly to confirm your appointment.",
    close: "Close",
    selectOption: "Select an option..."
  }
};

const ClientPortal: React.FC<ClientPortalProps> = ({ onBack }) => {
  const [lang, setLang] = useState<'es' | 'en'>('es');
  const [submitted, setSubmitted] = useState(false);
  
  const [formData, setFormData] = useState<ClientFormData>({
    clientType: 'new',
    language: 'es',
    isPhoneAppointment: false,
    fullName: '',
    phone: '',
    email: '',
    caseType: '',
    assignedParalegalId: undefined,
    questions: '',
    referralSource: ''
  });

  const t = translations[lang];
  const availableParalegals = PARALEGALS.filter(p => p.status === 'available');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate API call
    console.log("Form Submitted", formData);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-brand-dark flex items-center justify-center p-6 text-white">
        <div className="bg-white/10 backdrop-blur-md p-8 rounded-3xl border border-brand-gold/30 max-w-md text-center shadow-2xl animate-fade-in-up">
          <div className="w-20 h-20 bg-brand-success/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle size={40} className="text-brand-success" />
          </div>
          <h2 className="text-2xl font-bold font-sans mb-4">{t.successTitle}</h2>
          <p className="text-white/70 mb-8 leading-relaxed">{t.successMessage}</p>
          <button 
            onClick={onBack}
            className="w-full py-3 rounded-xl bg-brand-gold text-brand-dark font-bold hover:bg-white transition-colors"
          >
            {t.close}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-brand-dark text-white font-sans selection:bg-brand-gold selection:text-brand-dark">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-brand-darker/80 backdrop-blur-md border-b border-white/10 px-6 py-4">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <button 
            onClick={onBack}
            className="flex items-center gap-2 text-white/60 hover:text-brand-gold transition-colors text-sm font-bold uppercase tracking-wide"
          >
            <ArrowLeft size={18} />
            <span className="hidden sm:inline">{t.back}</span>
          </button>

          <div className="flex items-center gap-3">
            <Scale className="text-brand-gold" size={24} />
            <span className="font-bold text-lg hidden sm:block">EV Law Team</span>
          </div>

          <button
            onClick={() => setLang(prev => prev === 'es' ? 'en' : 'es')}
            className="flex items-center gap-2 bg-white/5 hover:bg-white/10 px-3 py-1.5 rounded-full border border-white/10 transition-colors"
          >
            <Globe size={16} className="text-brand-gold" />
            <span className="text-xs font-bold">{lang === 'es' ? 'ES' : 'EN'}</span>
          </button>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto p-6 space-y-12">
        {/* Hero */}
        <div className="text-center space-y-4 py-8">
          <h1 className="text-3xl md:text-5xl font-bold tracking-tight">{t.title}</h1>
          <p className="text-white/60 text-lg max-w-2xl mx-auto">{t.subtitle}</p>
        </div>

        {/* Availability Grid */}
        <section>
            <div className="flex items-center gap-3 mb-6">
                <div className="w-2 h-8 bg-brand-success rounded-full"></div>
                <h3 className="text-xl font-bold text-brand-success">{t.availabilityTitle}</h3>
            </div>
            
            {availableParalegals.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {availableParalegals.map(p => (
                        <div key={p.id} className="bg-white/5 border border-white/10 rounded-xl p-4 flex items-center gap-4 hover:bg-white/10 transition-colors group">
                            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-brand-gold to-brand-goldLight flex items-center justify-center text-brand-dark font-bold text-lg shrink-0">
                                {p.name.split(" ").map(n => n[0]).join("")}
                            </div>
                            <div className="overflow-hidden">
                                <p className="font-bold truncate group-hover:text-brand-gold transition-colors">{p.name}</p>
                                <p className="text-xs text-brand-success flex items-center gap-1">
                                    <div className="w-2 h-2 rounded-full bg-brand-success animate-pulse"></div>
                                    Available
                                </p>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="bg-white/5 rounded-xl p-8 text-center border border-dashed border-white/10">
                    <p className="text-white/50">{t.noAvailability}</p>
                </div>
            )}
        </section>

        {/* Booking Form */}
        <section className="bg-brand-darker rounded-3xl p-6 md:p-10 border border-brand-gold/20 shadow-2xl relative overflow-hidden">
             {/* Decor */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-brand-gold/5 rounded-full blur-3xl pointer-events-none translate-x-1/2 -translate-y-1/2"></div>

            <h3 className="text-2xl font-bold mb-8 relative z-10 flex items-center gap-3">
                <Calendar className="text-brand-gold" />
                {t.formTitle}
            </h3>

            <form onSubmit={handleSubmit} className="space-y-8 relative z-10 max-w-3xl">
                
                {/* Client Type Toggle */}
                <div className="flex p-1 bg-black/40 rounded-xl border border-white/10 max-w-md">
                    <button
                        type="button"
                        onClick={() => setFormData({...formData, clientType: 'new'})}
                        className={`flex-1 py-3 px-4 rounded-lg text-sm font-bold transition-all ${
                            formData.clientType === 'new' 
                            ? 'bg-brand-gold text-brand-dark shadow-lg' 
                            : 'text-white/60 hover:text-white'
                        }`}
                    >
                        {t.clientTypeNew}
                    </button>
                    <button
                        type="button"
                        onClick={() => setFormData({...formData, clientType: 'regular'})}
                        className={`flex-1 py-3 px-4 rounded-lg text-sm font-bold transition-all ${
                            formData.clientType === 'regular' 
                            ? 'bg-brand-gold text-brand-dark shadow-lg' 
                            : 'text-white/60 hover:text-white'
                        }`}
                    >
                        {t.clientTypeRegular}
                    </button>
                </div>

                {/* Main Fields Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                        <label className="text-xs font-bold uppercase tracking-wider text-brand-gold ml-1">{t.fullName}</label>
                        <div className="relative">
                            <User className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" size={18} />
                            <input 
                                required
                                type="text" 
                                value={formData.fullName}
                                onChange={e => setFormData({...formData, fullName: e.target.value})}
                                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:border-brand-gold focus:bg-white/10 transition-all placeholder:text-white/20"
                                placeholder="John Doe"
                            />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <label className="text-xs font-bold uppercase tracking-wider text-brand-gold ml-1">{t.phone}</label>
                        <div className="relative">
                            <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" size={18} />
                            <input 
                                required
                                type="tel" 
                                value={formData.phone}
                                onChange={e => setFormData({...formData, phone: e.target.value})}
                                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:border-brand-gold focus:bg-white/10 transition-all placeholder:text-white/20"
                                placeholder="+1 (555) 000-0000"
                            />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <label className="text-xs font-bold uppercase tracking-wider text-brand-gold ml-1">{t.email}</label>
                        <div className="relative">
                            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" size={18} />
                            <input 
                                required
                                type="email" 
                                value={formData.email}
                                onChange={e => setFormData({...formData, email: e.target.value})}
                                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:border-brand-gold focus:bg-white/10 transition-all placeholder:text-white/20"
                                placeholder="john@example.com"
                            />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <label className="text-xs font-bold uppercase tracking-wider text-brand-gold ml-1">{t.caseType}</label>
                        <div className="relative">
                            <FileText className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" size={18} />
                            <input 
                                required
                                type="text" 
                                value={formData.caseType}
                                onChange={e => setFormData({...formData, caseType: e.target.value})}
                                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:border-brand-gold focus:bg-white/10 transition-all placeholder:text-white/20"
                                placeholder="Residencia, Permiso de Trabajo, etc."
                            />
                        </div>
                    </div>
                </div>

                {/* Conditional Fields */}
                <div className="bg-white/5 rounded-2xl p-6 border border-white/5 space-y-6">
                    {formData.clientType === 'regular' ? (
                        <>
                            <div className="space-y-2">
                                <label className="text-xs font-bold uppercase tracking-wider text-brand-gold ml-1">{t.selectParalegal}</label>
                                <select 
                                    value={formData.assignedParalegalId || ''}
                                    onChange={e => setFormData({...formData, assignedParalegalId: Number(e.target.value)})}
                                    className="w-full bg-black/20 border border-white/10 rounded-xl py-3 px-4 focus:outline-none focus:border-brand-gold text-white appearance-none"
                                >
                                    <option value="">{t.selectOption}</option>
                                    {PARALEGALS.map(p => (
                                        <option key={p.id} value={p.id}>{p.name}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="space-y-2">
                                <label className="text-xs font-bold uppercase tracking-wider text-brand-gold ml-1">{t.questions}</label>
                                <textarea 
                                    rows={4}
                                    value={formData.questions}
                                    onChange={e => setFormData({...formData, questions: e.target.value})}
                                    className="w-full bg-black/20 border border-white/10 rounded-xl py-3 px-4 focus:outline-none focus:border-brand-gold focus:bg-black/40 transition-all placeholder:text-white/20 resize-none"
                                />
                            </div>
                        </>
                    ) : (
                        <div className="space-y-2">
                            <label className="text-xs font-bold uppercase tracking-wider text-brand-gold ml-1">{t.howDidYouHear}</label>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                {[
                                    {val: 'Instagram', label: t.sourceInstagram},
                                    {val: 'Google', label: t.sourceGoogle},
                                    {val: 'YouTube', label: t.sourceYouTube},
                                    {val: 'Referral', label: t.sourceReferral},
                                    {val: 'Other', label: t.sourceOther},
                                ].map((opt) => (
                                    <label key={opt.val} className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-all ${
                                        formData.referralSource === opt.val 
                                        ? 'bg-brand-gold/20 border-brand-gold' 
                                        : 'bg-transparent border-white/10 hover:bg-white/5'
                                    }`}>
                                        <input 
                                            type="radio" 
                                            name="source" 
                                            value={opt.val}
                                            checked={formData.referralSource === opt.val}
                                            onChange={e => setFormData({...formData, referralSource: e.target.value})}
                                            className="accent-brand-gold"
                                        />
                                        <span className="text-sm">{opt.label}</span>
                                    </label>
                                ))}
                            </div>
                        </div>
                    )}
                </div>

                {/* Preference Toggle */}
                <label className="flex items-center gap-4 cursor-pointer group">
                    <div className={`w-12 h-6 rounded-full p-1 transition-colors ${formData.isPhoneAppointment ? 'bg-brand-gold' : 'bg-white/20'}`}>
                        <div className={`w-4 h-4 bg-white rounded-full shadow-md transition-transform ${formData.isPhoneAppointment ? 'translate-x-6' : 'translate-x-0'}`}></div>
                    </div>
                    <input 
                        type="checkbox" 
                        className="hidden"
                        checked={formData.isPhoneAppointment}
                        onChange={e => setFormData({...formData, isPhoneAppointment: e.target.checked})}
                    />
                    <span className="text-sm font-medium group-hover:text-white transition-colors text-white/70">{t.phoneAppt}</span>
                </label>

                {/* Submit */}
                <button 
                    type="submit"
                    className="w-full py-4 rounded-xl bg-gradient-to-r from-brand-gold to-brand-goldLight text-brand-dark font-bold text-lg uppercase tracking-wider hover:brightness-110 hover:shadow-[0_0_20px_rgba(207,174,112,0.4)] active:scale-[0.99] transition-all"
                >
                    {t.submit}
                </button>

            </form>
        </section>

        <footer className="text-center text-white/30 text-xs pb-8">
            <p>Elio Vázquez Immigration Law Team • Desde 1987</p>
        </footer>
      </div>
    </div>
  );
};

export default ClientPortal;
