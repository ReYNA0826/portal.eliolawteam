import React from "react";
import { Users, Scale } from "lucide-react";

interface WelcomeProps {
  onSelectRole: (role: 'client' | 'staff') => void;
}

const WelcomeScreen: React.FC<WelcomeProps> = ({ onSelectRole }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-brand-dark to-brand-darker flex flex-col items-center justify-center p-6 text-white relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-[-20%] right-[-10%] w-[600px] h-[600px] rounded-full bg-brand-gold/5 blur-3xl"></div>
        <div className="absolute bottom-[-10%] left-[-10%] w-[400px] h-[400px] rounded-full bg-brand-success/5 blur-3xl"></div>
      </div>

      <div className="relative z-10 text-center mb-12 animate-fade-in-up">
        <div className="w-24 h-24 rounded-2xl mx-auto mb-6 bg-black flex flex-col items-center justify-center shadow-2xl border border-brand-gold/30">
            <Scale size={42} className="text-brand-gold mb-1" strokeWidth={1.5} />
            <div className="text-[10px] text-brand-gold font-serif tracking-widest opacity-80 mt-1">JUSTICE</div>
        </div>
        <h1 className="text-3xl md:text-5xl font-sans font-bold mb-4 tracking-tight">
          Elio Vázquez <span className="text-brand-gold">Immigration Law</span>
        </h1>
        <p className="text-white/60 text-lg font-serif italic max-w-xl mx-auto">
          "Justicia y compromiso para la comunidad inmigrante desde 1987"
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-4xl relative z-10">
        {/* Client Option */}
        <button
          onClick={() => onSelectRole('client')}
          className="group relative bg-white/5 hover:bg-white/10 border border-brand-gold/30 hover:border-brand-gold rounded-2xl p-8 transition-all duration-300 hover:transform hover:-translate-y-1 hover:shadow-2xl hover:shadow-brand-gold/10 text-left flex flex-col gap-4"
        >
          <div className="w-14 h-14 rounded-full bg-gradient-to-br from-brand-gold to-brand-goldLight flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
            <Users size={28} className="text-brand-dark" />
          </div>
          <div>
            <h2 className="text-2xl font-bold font-sans mb-2 group-hover:text-brand-gold transition-colors">Soy Cliente</h2>
            <p className="text-white/60 text-sm leading-relaxed">
              Deseo agendar una cita, ver disponibilidad o contactar a mi paralegal.
            </p>
          </div>
          <div className="mt-auto pt-4 flex items-center text-brand-gold text-sm font-bold uppercase tracking-wider">
            Ingresar al Portal <span className="ml-2 group-hover:translate-x-1 transition-transform">→</span>
          </div>
        </button>

        {/* Staff Option */}
        <button
          onClick={() => onSelectRole('staff')}
          className="group relative bg-brand-darker/50 hover:bg-black/40 border border-white/10 hover:border-white/30 rounded-2xl p-8 transition-all duration-300 hover:transform hover:-translate-y-1 hover:shadow-xl text-left flex flex-col gap-4"
        >
          <div className="w-14 h-14 rounded-full bg-white/10 flex items-center justify-center shadow-lg group-hover:bg-white/20 transition-colors">
            <Scale size={28} className="text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold font-sans mb-2 group-hover:text-white transition-colors">Soy Paralegal / Staff</h2>
            <p className="text-white/60 text-sm leading-relaxed">
              Acceso administrativo para gestionar citas y disponibilidad.
            </p>
          </div>
          <div className="mt-auto pt-4 flex items-center text-white/50 group-hover:text-white text-sm font-bold uppercase tracking-wider transition-colors">
            Acceso Interno <span className="ml-2 group-hover:translate-x-1 transition-transform">→</span>
          </div>
        </button>
      </div>

      <footer className="mt-16 text-white/30 text-xs text-center">
        © {new Date().getFullYear()} Elio Vázquez Law Team. All Rights Reserved.
      </footer>
    </div>
  );
};

export default WelcomeScreen;
