import { Paralegal } from './types';

// Using the provided list, adding emails derived from names for login logic
// In a real app, emails would come from a backend.
export const PARALEGALS: Paralegal[] = [
  { id: 1, name: "Jose Zavarce", email: "jose.zavarce@example.com", status: "available", nextAppointments: ["Consulta inicial - 2:00 PM"] },
  { id: 2, name: "Maria Hernandez", email: "maria.hernandez@example.com", status: "busy", nextAppointments: ["Revisión de documentos - 11:00 AM"] },
  { id: 3, name: "Fabricio González", email: "fabricio.gonzalez@example.com", status: "available", nextAppointments: [] },
  { id: 4, name: "Oscar Gutierrez", email: "oscar.gutierrez@example.com", status: "busy", nextAppointments: ["Firma de documentos - 3:30 PM"] },
  { id: 5, name: "Walmelys Flores", email: "walmelys.flores@example.com", status: "available", nextAppointments: ["Seguimiento caso familiar - 4:00 PM"] },
  { id: 6, name: "Karina Tirado", email: "karina.tirado@example.com", status: "busy", nextAppointments: [] },
  { id: 7, name: "Leidys Godoy", email: "leidys.godoy@example.com", status: "available", nextAppointments: [] },
  { id: 8, name: "Adela Martinez", email: "adela.martinez@example.com", status: "available", nextAppointments: ["Consulta telefónica - 5:15 PM"] },
  { id: 9, name: "Nelisa Pena", email: "nelisa.pena@example.com", status: "available", nextAppointments: [] },
  { id: 10, name: "Daniel Arias", email: "daniel.arias@example.com", status: "available", nextAppointments: [] },
  { id: 11, name: "Tony Marval", email: "tony.marval@example.com", status: "busy", nextAppointments: ["Entrevista cliente - 10:30 AM"] },
  { id: 12, name: "Cioly Zambrano", email: "cioly.zambrano@example.com", status: "available", nextAppointments: [] },
  { id: 13, name: "Axa Rebeca Perez Petit", email: "axa.perez@example.com", status: "available", nextAppointments: [] },
  { id: 14, name: "Maria de Gaetano", email: "maria.degaetano@example.com", status: "available", nextAppointments: [] },
  { id: 15, name: "Leonardo Perez", email: "leonardo.perez@example.com", status: "available", nextAppointments: [] },
  { id: 16, name: "Minerva Mendoza Paipa", email: "minerva.mendoza@example.com", status: "available", nextAppointments: [] },
];
